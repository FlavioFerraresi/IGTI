import React from 'react';

export default function Names({ children }) {
  return <div>{children}</div>;
}
